# Kmeans-code-assignment
## This is a simple Kmeans package to find best K.
